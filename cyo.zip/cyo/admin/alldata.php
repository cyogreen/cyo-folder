<html>
    <head>
        <title>Farmocart</title>
        <?php include 'header.php';?>
    </head>
    <body>
        <header class="head">
            <a href="http://farmocart.com">Farmocart.com</a>
        </header>
        <section class="sec1">
            <div class="task_one">
                <h4>Data's of Farmocart</h4>
            </div>
            <div class="task_list">
                <a href="employeelist.php"><div class="task_block">
                <img src="images/add.png">
                <div>Employee</div>
                </div></a>
            </div>
            </section>
    </body>
</html>