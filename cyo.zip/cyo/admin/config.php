<?php 
$con=mysqli_connect('getmlmsoftware.com','getmlmsoftware','Realforce@123','getmlmsoftware_cyo');
?>
