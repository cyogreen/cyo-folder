<html>
    <head>
        <title>CYO Green</title>
        <?php include 'header.php';?>
    </head>
    <body>
        <header class="head">
            <a href="http://getmlmsoftware.com/demo/cyo/admin">CYO Green</a>
        </header>
        <section class="sec1">
            <div class="task_one">
                <h4>Add Category</h4>
            </div>
            </section>
    </body>
</html>